library(unmarked)
library(ggplot2)

tay <- read.csv("tay_pcount.open.csv") 
site.covs <- read.csv("ts.sitecovs_500m.csv") 
obs1.covs <- read.csv("ts.sample_hour.csv") 
obs2.covs <- read.csv("ts.sample_juliandate.csv")  
obs.covs <- list(hour=obs1.covs, date=obs2.covs);is.na(obs.covs) <- NA 
years <- matrix(c('01', '02', '03', '04'), nrow(tay), 4, byrow=T) 

upc.tay <- unmarkedFramePCO (y=tay, siteCovs=site.covs, obsCovs=obs.covs, yearlySiteCovs=list(year=years), numPrimary=4)
summary(upc.tay) 
str(upc.tay)

sc <- siteCovs(upc.tay) 
sc <- scale(sc)
siteCovs(upc.tay) <- sc

oc <- obsCovs(upc.tay) 
oc <- scale(oc)
obsCovs(upc.tay) <- oc

summary(upc.tay) 
str(upc.tay)
png(file = "ci_tay_matrix.png", width = 800, height = 700)
plot (upc.tay) 
dev.off()

fm1 <- pcountOpen(~1, ~1, ~1, ~1, upc.tay, K=50)
fm2 <- pcountOpen(~1, ~1, ~1, ~hour+date+year-1, upc.tay, K=50)
fm3 <- pcountOpen(~1, ~1, ~1, ~primary+hour+date+year-1, upc.tay, K=50)
fm4 <- pcountOpen(~1, ~1, ~1, ~secondary+hour+date+year-1, upc.tay, K=50)
fm5 <- pcountOpen(~1, ~1, ~1, ~plantation+hour+date+year-1, upc.tay, K=50)
fm6 <- pcountOpen(~primary, ~1, ~1, ~primary+hour+date+year-1, upc.tay, K=50)
fm7 <- pcountOpen(~secondary, ~1, ~1, ~secondary+hour+date+year-1, upc.tay, K=50)
fm8 <- pcountOpen(~plantation, ~1, ~1, ~plantation+hour+date+year-1, upc.tay, K=50)

models <- fitList('(fm1)' = fm1,
				          '(fm2)' = fm2,
				          '(fm3)' = fm3, 
			          	'(fm4)' = fm4,
				          '(fm5)' = fm5,
			           	'(fm6)' = fm6,
			          	'(fm7)' = fm7,
			          	'(fm8)' = fm8)
				
ms <- modSel(models) 
ms
toExport <- as(ms,"data.frame")

# Best Model - fm6
lam.coef <- exp(coef(fm6, type="lambda"))
lam.coef
lam.SE <- exp(SE(fm6, type="lambda"))
lam.SE
lam.confint <- exp(confint(fm6, type="lambda"))
lam.confint

p.coef <- plogis(coef(fm6, type="det"))
p.coef
p.SE <- plogis(SE(fm6, type="det"))
p.SE
p.confint <- plogis(confint(fm6, type="det"))
p.confint
