library(unmarked)
library(ggplot2)

tay <- read.csv("tay_pcount.open.csv")
site.covs <- read.csv("ts.sitecovs_500m.csv")
obs1.covs <- read.csv("ts.sample_hour.csv") 
obs2.covs <- read.csv("ts.sample_juliandate.csv") 
obs.covs <- list(hour=obs1.covs, date=obs2.covs);is.na(obs.covs) <- NA
years <- matrix(c('01', '02', '03', '04'), nrow(tay), 4, byrow=T) 

upc.tay <- unmarkedFramePCO (y=tay, siteCovs=site.covs, obsCovs=obs.covs, yearlySiteCovs=list(year=years), numPrimary=4)
summary(upc.tay) 
str(upc.tay)

sc <- siteCovs(upc.tay) 
sc <- scale(sc)
siteCovs(upc.tay) <- sc

oc <- obsCovs(upc.tay) 
oc <- scale(oc)
obsCovs(upc.tay) <- oc

summary(upc.tay) 
str(upc.tay)
png(file = "tay_matrix.png", width = 800, height = 700)
plot (upc.tay) 
dev.off()

SITE.COVS <- as.matrix(site.covs[,1:3])
y.tay <- as.matrix(tay[,1:32])
sd.SITE.COVS <- sd(c(SITE.COVS), na.rm=TRUE)
mean.SITE.COVS <- mean(SITE.COVS, na.rm=TRUE)
SITE.COVS <- (SITE.COVS - mean.SITE.COVS) / sd.SITE.COVS

HOUR <- as.matrix(obs1.covs[,1:32])
y.tay <- as.matrix(tay[,1:32])
y.tay[is.na(HOUR) != is.na(y.tay)] <- NA
sd.HOUR <- sd(c(HOUR), na.rm=TRUE)
mean.HOUR <- mean(HOUR, na.rm=TRUE)
HOUR <- (HOUR - mean.HOUR) / sd.HOUR

DATE <- as.matrix(obs2.covs[,1:32])
y.tay <- as.matrix(tay[,1:32])
y.tay[is.na(DATE) != is.na(y.tay)] <- NA
sd.DATE <- sd(c(DATE), na.rm=TRUE)
mean.DATE <- mean(DATE, na.rm=TRUE)
DATE <- (DATE - mean.DATE) / sd.DATE

png(file = "tay_lambda_primary.png", width = 800, height = 800)
fm1 <- pcountOpen (~primary, ~1, ~1, ~1, upc.tay, K=50)
nd <- data.frame(primary=seq(-0.9258, 1.8686, length=50))
E.lambda <- predict(fm1, type="lambda", newdata=nd, appendData=TRUE)
E.lambda$primaryOrig <- E.lambda$primary*sd.SITE.COVS + mean.SITE.COVS
with(E.lambda, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(primaryOrig, Predicted, ylim=c(0,30), xlim=c(0,100), type="l", 
       xlab="Percent of vegetation cover",
       ylab=expression("Expected abundance " (lambda)), cex.lab=1.5, cex.axis=1.5)
  lines(primaryOrig, Predicted, col="#538b33", lwd=2) 
  lines(primaryOrig, Predicted+1.96*SE, lty = 'dashed', col="#538b33", lwd=2)
  lines(primaryOrig, Predicted-1.96*SE, lty = 'dashed', col="#538b33", lwd=2)
})
dev.off()

png(file = "tay_lambda_secondary.png", width = 800, height = 800)
fm1 <- pcountOpen (~secondary, ~1, ~1, ~1, upc.tay, K=50)
nd <- data.frame(secondary=seq(-0.9258, 1.8686, length=50))
E.lambda <- predict(fm1, type="lambda", newdata=nd, appendData=TRUE)
E.lambda$secondaryOrig <- E.lambda$secondary*sd.SITE.COVS + mean.SITE.COVS
with(E.lambda, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(secondaryOrig, Predicted, ylim=c(0,30), xlim=c(0,100), type="l", 
       xlab="Percent of vegetation cover",
       ylab=expression("Expected abundance " (lambda)), cex.lab=1.5, cex.axis=1.5)
  lines(secondaryOrig, Predicted, col="#bcdcbc", lwd=2) 
  lines(secondaryOrig, Predicted+1.96*SE, lty = 'dashed', col="#bcdcbc")
  lines(secondaryOrig, Predicted-1.96*SE, lty = 'dashed', col="#bcdcbc")
})
dev.off()

png(file = "tay_lambda_plantation.png", width = 800, height = 800)
fm1 <- pcountOpen (~plantation, ~1, ~1, ~1, upc.tay, K=50)
nd <- data.frame(plantation=seq(-0.9258, 1.8686, length=50))
E.lambda <- predict(fm1, type="lambda", newdata=nd, appendData=TRUE)
E.lambda$plantationOrig <- E.lambda$plantation*sd.SITE.COVS + mean.SITE.COVS
with(E.lambda, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(plantationOrig, Predicted, ylim=c(0,30), xlim=c(0,100), type="l", 
       xlab="Percent of vegetation cover",
       ylab=expression("Expected abundance " (lambda)), cex.lab=1.5, cex.axis=1.5)
  lines(plantationOrig, Predicted, col="#eca440", lwd=2) 
  lines(plantationOrig, Predicted+1.96*SE, lty = 'dashed', col="#eca440")
  lines(plantationOrig, Predicted-1.96*SE, lty = 'dashed', col="#eca440")
})
dev.off()

png(file = "tay_p_primary.png", width = 800, height = 800)
fm1 <- pcountOpen (~1, ~1, ~1, ~primary, upc.tay, K=50)
nd <- data.frame(primary=seq(-0.9258, 1.8686, length=50))
E.p <- predict(fm1, type="det", newdata=nd, appendData=TRUE)
E.p$primaryOrig <- E.p$primary*sd.SITE.COVS + mean.SITE.COVS
with(E.p, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(primaryOrig, Predicted, ylim=c(0,0.3), xlim=c(0,100), type="l", 
       xlab="Percent of vegetation cover",
       ylab=expression("Probability of detection " (italic(p))), cex.lab=1.5, cex.axis=1.5)
  lines(primaryOrig, Predicted, col="#538b33", lwd=3) 
  lines(primaryOrig, Predicted+1.96*SE, lty = 'dashed', col="#538b33", lwd=2)
  lines(primaryOrig, Predicted-1.96*SE, lty = 'dashed', col="#538b33", lwd=2)
})
dev.off()

png(file = "tay_p_secondary.png", width = 800, height = 800)
fm1 <- pcountOpen (~1, ~1, ~1, ~secondary, upc.tay, K=50)
nd <- data.frame(secondary=seq(-0.9258, 1.8686, length=50))
E.p <- predict(fm1, type="det", newdata=nd, appendData=TRUE)
E.p$secondaryOrig <- E.p$secondary*sd.SITE.COVS + mean.SITE.COVS
with(E.p, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(secondaryOrig, Predicted, ylim=c(0,0.3), xlim=c(0,100), type="l", 
       xlab="Percent of vegetation cover",
       ylab=expression("Probability of detection " (italic(p))), cex.lab=1.5, cex.axis=1.5)
  lines(secondaryOrig, Predicted, col="#bcdcbc", lwd=2) 
  lines(secondaryOrig, Predicted+1.96*SE, lty = 'dashed', col="#bcdcbc")
  lines(secondaryOrig, Predicted-1.96*SE, lty = 'dashed', col="#bcdcbc")
})
dev.off()

png(file = "tay_p_plantation.png", width = 800, height = 800)
fm1 <- pcountOpen (~1, ~1, ~1, ~plantation, upc.tay, K=50)
nd <- data.frame(plantation=seq(-0.9258, 1.8686, length=50))
E.p <- predict(fm1, type="det", newdata=nd, appendData=TRUE)
E.p$plantationOrig <- E.p$plantation*sd.SITE.COVS + mean.SITE.COVS
with(E.p, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(plantationOrig, Predicted, ylim=c(0,0.3), xlim=c(0,100), type="l", 
       xlab="Percent of vegetation cover",
       ylab=expression("Probability of detection " (italic(p))), cex.lab=1.5, cex.axis=1.5)
  lines(plantationOrig, Predicted, col="#eca440", lwd=2) 
  lines(plantationOrig, Predicted+1.96*SE, lty = 'dashed', col="#eca440")
  lines(plantationOrig, Predicted-1.96*SE, lty = 'dashed', col="#eca440")
})
dev.off()

png(file = "tay_p_hour.png", width = 800, height = 800)
fm1 <- pcountOpen (~1, ~1, ~1, ~hour, upc.tay, K=50)
nd <- data.frame(hour=seq(-3.0228, 3.253, length=50), year=factor("2008", levels=c(unique(years))), primary=50)
E.p <- predict(fm1, type="det", newdata=nd, appendData=TRUE)
E.p$hourOrig <- E.p$hour*sd.HOUR + mean.HOUR
with(E.p, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(hourOrig, Predicted, ylim=c(0,0.3), type="l", col= "black",
       xlab="Sampling effort (hours)", 
       ylab=expression("Probability of detection " (italic(p))), cex.lab=1.5, cex.axis=1.5)
  lines(hourOrig, Predicted+1.96*SE, lty = 'dashed', col = gray(0.7))
  lines(hourOrig, Predicted-1.96*SE, lty = 'dashed', col = gray(0.7))
})
dev.off()

png(file = "tay_p_date.png", width = 800, height = 800)
fm1 <- pcountOpen (~1, ~1, ~1, ~date, upc.tay, K=50)
nd <- data.frame(date=seq(-1.352, 1.454, length=50), year=factor("2008", levels=c(unique(years))), primary=50)
E.p <- predict(fm1, type="det", newdata=nd, appendData=TRUE)
E.p$dateOrig <- E.p$date*sd.DATE + mean.DATE
with(E.p, {
  par(mar = c(5, 5.5, 2, 2)) 
  plot(dateOrig, Predicted, ylim=c(0,0.3), type="l", col= "black",
       xlab="Julian date (2008-2011)", 
       ylab=expression("Probability of detection " (italic(p))), cex.lab=1.5, cex.axis=1.5)
  lines(dateOrig, Predicted+1.96*SE, lty = 'dashed', col = gray(0.7))
  lines(dateOrig, Predicted-1.96*SE, lty = 'dashed', col = gray(0.7))
})
dev.off()
