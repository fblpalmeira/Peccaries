library(ggplot2) 

dat <- read.csv("ci_peccaries_abundance2.csv", header = T, sep=";")
dat2 <- dat
dat2$sp <- factor(dat2$sp, levels = c("Tayassu pecari", "Pecari tajacu"))
dat2$landuse <- factor(dat2$landuse, levels = c("Primary forest", "Secondary forest", "Forest plantation"))
png(file = "ci_peccaries_abundance.png", width = 800, height = 700)
plot<-ggplot(dat2, aes(x=landuse, y=mu, group=landuse, color=landuse))+ 
  geom_line(position=position_dodge(width=0.50), linetype = 2, colour="black")+
  geom_pointrange(aes(ymin=lcl, ymax=ucl, shape=landuse), 
                  position=position_dodge(width=0.50))+ 
  labs(x = "", y = "")+
  scale_color_manual(values = c("#538b33", "#bcdcbc", "#eca440"))+
  facet_grid(type~sp, scales = "free", switch = "y")+
  theme_bw()+ 
  theme (panel.grid.major.y = element_blank(), 
         panel.grid.minor.y = element_blank())+ 
  theme (panel.grid.major.x = element_blank(), 
         panel.grid.minor.x = element_blank())+
  theme (axis.title.x=element_text(size=20))+ 
  theme (axis.title.y=element_text(size=20))+
  theme (axis.text.x=element_text(size=14))+ 
  theme (axis.text.y=element_text(size=14))+
  theme(strip.placement = "outside", # Place facet labels outside x axis labels.
        strip.background = element_blank(), # Make facet label background white.
        legend.position = "none",
        strip.text.y = element_text(angle = 0, size=20),
        strip.text.x = element_blank())
plot
dev.off()
  