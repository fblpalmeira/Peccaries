cor <- read.csv("ts.sitecovs_500m.csv", header=T, sep=",", dec=".")
summary(cor)
	 
cor.test(cor$primary,cor$plantation,method="spearman")
cor.test(cor$primary,cor$secondary,method="spearman")
cor.test(cor$plantation,cor$secondary,method="spearman")

cor.test(cor$primary,cor$plantation,method="kendall")
cor.test(cor$primary,cor$secondary,method="kendall")
cor.test(cor$plantation,cor$secondary,method="kendall")	
	
plot(cor$primary,cor$plantation) 
plot(cor$primary,cor$secondary) 
plot(cor$plantation,cor$secondary)
